this is app simple trivia quiz on android, integration with database sqlite.
